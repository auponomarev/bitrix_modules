<?php

namespace Bitrix\Tasks\Internals\Notification;

class EntityCode
{
	public const CODE_TASK = 'TASK';
	public const CODE_COMMENT = 'COMMENT';
}